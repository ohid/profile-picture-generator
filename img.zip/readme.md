# Profile Picture Generator

Profile Picture Generator is specially built for Jessore Zilla School boys to make their Zilla School labeled profile picture


### Version
master

### Live Demo
http://reunion.ohidul.com/en

### Installation

Clone this repository to your htdocs folder-
```sh
$ git clone https://github.com/ohid/profile-picture-generator.git profile-pic-generator
```


Now you are all setup to go. 

## Have any  question?
ask me at ohidul.islam951@gmail.com


# Screenshots

Home page shortening url
![Home page shortening url](https://f80b40e2f310199b7fee1416426c7e105de8fafa.googledrive.com/host/0B6SVI7iK7bjjOEFkNDJjXzBQRG8)
